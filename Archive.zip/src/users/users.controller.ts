import { Controller, Post } from '@nestjs/common';

import { UsersService } from './users.service';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  @Post()
  userSignUp() {
    return 'user signup route';
  }

  @Post('/login')
  userLogin() {
    return 'user login route';
  }

  @Post('/follow-user/:id')
  followUser() {
    return 'follow a user route';
  }

  @Post('/unfollow-user/:id')
  unfollowUser() {
    return 'unfollow user route';
  }
}
