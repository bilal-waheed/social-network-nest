import { BadRequestException, Injectable } from '@nestjs/common';
import { BaseExceptionFilter } from '@nestjs/core';

@Injectable()
export class UsersService {
  async signup(
    firstName: string,
    lastName: string,
    handle: string,
    password: string,
  ) {
    //validate the inputs
    if (!firstName || !lastName || !handle || !password) {
      throw new BadRequestException('Input fields incomplete');
    }
    //hash the password
    const hashedPassword = password + 'salt';
    //create an object and add it to the database
    const userObject = {
      firstName,
      lastName,
      handle,
      hashedPassword,
    };
  }

  async login(handle: string, password: string) {
    if (!handle || !password) {
      throw new BadRequestException('Input fields incomplete');
    }
    //find the user hande + compare the password hash
    //return a login success message
  }

  async followUser(userId: string) {
    //this is a protected route
    
    //find the user by the input userid
    //add the user in the following array
  }
}
